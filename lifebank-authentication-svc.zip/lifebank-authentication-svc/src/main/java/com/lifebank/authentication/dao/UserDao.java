package com.lifebank.authentication.dao;

import org.springframework.stereotype.Repository;

import com.lifebank.authentication.entity.User;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

@Repository
public interface UserDao extends CrudRepository<User,Integer>{
	//patron de accesoa datos.
	//nativeQuery=true
	
	@Query(value = "select u.id, u.username, u.userPassword, u.status from User u where u.username= :usrname and u.userPassword= :password")
	public List<User> getUserInfo(@Param("usrname") String username, @Param("password") String password);

}
