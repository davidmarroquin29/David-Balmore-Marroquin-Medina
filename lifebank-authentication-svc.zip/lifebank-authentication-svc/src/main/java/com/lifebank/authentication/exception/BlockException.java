package com.lifebank.authentication.exception;

public class BlockException extends Exception{

}
