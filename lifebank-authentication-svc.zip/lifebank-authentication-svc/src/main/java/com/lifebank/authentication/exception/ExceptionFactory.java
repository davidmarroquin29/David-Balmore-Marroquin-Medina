package com.lifebank.authentication.exception;

public class ExceptionFactory {

	public Exception getInstance(String exceptionType){
		//pendiente de desarrollar
		return null;
		
	}
}
