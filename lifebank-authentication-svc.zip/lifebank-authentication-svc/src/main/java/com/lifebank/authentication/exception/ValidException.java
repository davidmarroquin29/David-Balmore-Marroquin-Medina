package com.lifebank.authentication.exception;

public class ValidException extends Exception{

}
