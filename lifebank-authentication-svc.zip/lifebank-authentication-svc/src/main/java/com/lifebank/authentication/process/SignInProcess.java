package com.lifebank.authentication.process;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.lifebank.authentication.dao.UserDao;
import com.lifebank.authentication.entity.User;
//import com.lifebank.authentication.dao.SignInDao;
import com.lifebank.authentication.exception.BlockException;
import com.lifebank.authentication.exception.ValidException;
import com.lifebank.authentication.pojos.signin.RequestSignIn;
import com.lifebank.authentication.pojos.signin.ResponseSignIn;
import com.lifebank.authentication.utils.JWT;

@Service
public class SignInProcess {
	
	Environment env;
	UserDao userDao;
	
	@Autowired
	public SignInProcess(Environment env, UserDao userDao){
		this.env = env;
		this.userDao = userDao;
	}
	
	public ResponseSignIn process(RequestSignIn request) throws ValidException, BlockException{
		String code = "000";
		ResponseSignIn response = new ResponseSignIn();
		String tkn = "";
		List<User> userList = userDao.getUserInfo(request.getUsername(), request.getPassword());
			
		if (userList.size()!=1){
			throw new ValidException();
		}else if (!"A".equals(userList.get(0).getStatus())){
			throw new BlockException();
		}
		
		//Creando JWT
		Map<String, Object> mapJWT = new HashMap<String, Object>();
		
		
		mapJWT.put("usrId", userList.get(0).getId());
		mapJWT.put("usrIp", request.getIp());
		
		JWT jwt = new JWT(mapJWT,
				env.getProperty("service.jwt.secret"),
				env.getProperty("service.jwt.subject"),
				env.getProperty("service.jwt.issuer"),
				Long.parseLong(env.getProperty("service.jwt.expiration-time")));
		
		response.setTkn(jwt.generate());
		
		return response;
	}
}
