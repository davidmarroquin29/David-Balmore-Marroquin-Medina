package com.lifebank.products;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifebankProductsSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifebankProductsSvcApplication.class, args);
	}

}
