package com.lifebank.products.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.products.exception.BlockException;
import com.lifebank.products.exception.ValidException;
import com.lifebank.products.pojos.service.getproducts.GetProductsResponse;
import com.lifebank.products.process.ProductsProcess;

@RestController
@PropertySource("classpath:configuration.properties")
@RequestMapping("${service.url}")
public class Controller {
	Environment env;
	ProductsProcess process;
	
	@Autowired
	public Controller(Environment env, ProductsProcess process){
		this.env = env;
		this.process = process;
	}
	
	@GetMapping("${service.url.endpoint.get-products}")
	public GetProductsResponse getProducts(@PathVariable("userid") String userId) throws ValidException, BlockException{
		GetProductsResponse response;
		
			response = process.process(userId);
			return response;
		
	}

}
