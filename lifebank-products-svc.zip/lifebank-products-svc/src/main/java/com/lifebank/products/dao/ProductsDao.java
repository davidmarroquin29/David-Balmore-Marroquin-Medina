package com.lifebank.products.dao;

import org.springframework.stereotype.Repository;

import com.lifebank.products.pojos.entity.ProductsxUser;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

@Repository
public interface ProductsDao extends CrudRepository<ProductsxUser,Integer>{
	//patron de accesoa datos.
	//nativeQuery=true
	
	@Query(value = "select p from ProductsxUser p where p.usrId= :usrId")
	public List<ProductsxUser> getProdInfo(@Param("usrId") Integer usrId);

}
