package com.lifebank.products.exception;

public class BlockException extends Exception{

}
