package com.lifebank.products.exception;

public class ExceptionFactory {

	public Exception getInstance(String exceptionType){
		switch (exceptionType){
		case "INVALID_CREDENTIALS":
			return new ValidException();
		case "BLOCKED_ACCOUNT":
			return new BlockException();
		}
		return null;
		
	}
}
