package com.lifebank.products.exception;

public class ValidException extends Exception{

}
