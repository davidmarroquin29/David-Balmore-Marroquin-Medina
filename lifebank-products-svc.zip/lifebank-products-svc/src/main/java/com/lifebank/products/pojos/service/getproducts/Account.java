package com.lifebank.products.pojos.service.getproducts;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Account {
	@JsonProperty("loan")
	List<Product> loan = new ArrayList<>();
	@JsonProperty("creditCard")
	List<Product> creditCard = new ArrayList<>();
	@JsonProperty("personal")
	List<Product> personal = new ArrayList<>();
	
	public List<Product> getLoan() {
		return loan;
	}
	public void setLoan(List<Product> loan) {
		this.loan = loan;
	}
	public List<Product> getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(List<Product> creditCard) {
		this.creditCard = creditCard;
	}
	public List<Product> getPersonal() {
		return personal;
	}
	public void setPersonal(List<Product> personal) {
		this.personal = personal;
	}


}
