package com.lifebank.products.pojos.service.getproducts;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GetProductsResponse {
	@JsonProperty("accounts")
	Account accounts;

	public Account getAccounts() {
		return accounts;
	}

	public void setAccounts(Account accounts) {
		this.accounts = accounts;
	}
	
	
}
