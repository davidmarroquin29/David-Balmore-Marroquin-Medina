package com.lifebank.products.process;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.lifebank.products.dao.ProductsDao;
//import com.lifebank.authentication.dao.SignInDao;
import com.lifebank.products.exception.BlockException;
import com.lifebank.products.exception.ValidException;
import com.lifebank.products.pojos.entity.ProductsxUser;
import com.lifebank.products.pojos.service.getproducts.Account;
import com.lifebank.products.pojos.service.getproducts.GetProductsResponse;
import com.lifebank.products.pojos.service.getproducts.Product;

@Service
public class ProductsProcess {
	
	Environment env;
	ProductsDao productDao;
	
	@Autowired
	public ProductsProcess(Environment env, ProductsDao productDao){
		this.env = env;
		this.productDao = productDao;
	}
	
	public GetProductsResponse process(String userId) throws ValidException, BlockException{
		
		GetProductsResponse response = new GetProductsResponse();
		
		List<ProductsxUser> products = new ArrayList<>(); 
				products = productDao.getProdInfo(Integer.valueOf(userId));
		
		Account account = new Account();
		Product product;
		List<Product> loan = new ArrayList<>();
		List<Product> creditCard = new ArrayList<>();
		List<Product> personal = new ArrayList<>();
		
		for (ProductsxUser prod : products){
			product = new Product();
			product.setId(String.valueOf(prod.getId()));
			product.setName(prod.getName());
			switch (prod.getProdId()){
			case 1:
				loan.add(product);
			case 2:
				creditCard.add(product);
			case 3:
				personal.add(product);
			}
		}
		
		account.setCreditCard(creditCard);
		account.setLoan(loan);
		account.setPersonal(personal);
		
		response.setAccounts(account);
		
		return response;
	}
}
